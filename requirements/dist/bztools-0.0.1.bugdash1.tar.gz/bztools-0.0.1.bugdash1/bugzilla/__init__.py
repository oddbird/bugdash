VERSION = (0, 0, 1, "bugdash1")
__version__ = '.'.join(map(str, VERSION))
