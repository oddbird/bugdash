Promise Objects
===============

.. automodule:: remoteobjects.promise
   :members:
