VERSION = (0, 0, 1, "bugdash")
__version__ = '.'.join(map(str, VERSION))
